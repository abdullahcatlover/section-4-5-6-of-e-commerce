import React from "react";
import { categories } from "./data-categories";

const App =()=> {

    return (
        <div className="categories-container">
            {categories.map(({title}) => (
                 <div className="category-container">
                  <div className="background-image"/>
                 <div className="category-body-container">
                     <h2>{title}</h2>
                     <p>shop now</p>
                 </div>
             </div>
            ))}
           
        </div>
    )
}

export default App;