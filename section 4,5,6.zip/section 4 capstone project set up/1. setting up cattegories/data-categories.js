export const categories = [
    {
       id: 1,
       title: "Hats",
       
    },
    {
        id: 2,
        title: "Jackets",
        
     },
     {
        id: 3,
        title: "Sneackers",
        
     },
     {
        id: 4,
        title: "Womens",
        
     },
     {
        id: 5,
        title: "Mens",
        
     }
]