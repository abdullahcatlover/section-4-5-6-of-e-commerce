import React from "react";
import "./categories.styles.scss";
import CategoriesContainer from "./components/categories-container/categories.container";


const App =()=> {

    return (
       <div>
           <CategoriesContainer/>
       </div>
    )
}

export default App;