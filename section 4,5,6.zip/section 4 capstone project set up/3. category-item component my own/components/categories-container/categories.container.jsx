/* import "../categories-container/categories-container.styles.scss" */
import CategoryItem from "../category-item/category-item";
import { categories } from "../../data-categories";



const CategoriesContainer =()=> {
    return(
        <div className="categories-container">
        {categories.map((category) => (
           <CategoryItem key={category.id} category={category}/>
        ))}
       
    </div>
    )
}

export default CategoriesContainer;

/* in this lesson you made category item by yourself, the name of the component might be different*/