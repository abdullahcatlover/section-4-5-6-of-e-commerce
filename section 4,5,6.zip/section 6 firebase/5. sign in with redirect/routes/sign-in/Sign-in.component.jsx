import { useEffect } from "react";
import {getRedirectResult} from "firebase/auth"
import {auth,
    signInWithGooglePopup,
    signInWithGoogleRedirect,
     createUserDocumentFromAuth} from "../../utils/firebase/firebase.utils";
import { async } from "@firebase/util";





const SignIn =()=> {
/* useEffect(async ()=> {
   const response = await getRedirectResult(auth);
   if(response){
    const userDocRef = await createUserDocumentFromAuth(response.user)
   }
}, []) */

    const logGoogleUser = async () => {
        const {user} = await signInWithGooglePopup();
        const userDocRef = await createUserDocumentFromAuth(user)
    }
    
    return (
        <div>
            <h1>Sign In Page</h1>
            <button onClick={logGoogleUser}>Sign In with google PopUp</button>
            {/* <button onClick={signInWithGoogleRedirect}>Sign In with google Redirect</button> */}
        </div>
    )
}

export default SignIn;

/*
1) getRedirectResult  If sign-in succeeded, returns the signed in user. If sign-in was unsuccessful, fails with an error. If no redirect operation was called, returns null.


getRedirectResult this is gonna get auth


  const logGoogleRedirectUser = async () => {
        const {user} = await signInWithGoogleRedirect();
        console.log({user});
    }  insted of doing this we call directly  signInWithGoogleRedirect
*/