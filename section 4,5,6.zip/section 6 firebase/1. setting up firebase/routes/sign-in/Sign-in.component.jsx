const SignIn =()=> {
    return (
        <div>
            <h1>Sign In Page</h1>
        </div>
    )
}

export default SignIn;