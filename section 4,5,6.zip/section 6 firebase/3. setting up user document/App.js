import { Routes, Route} from "react-router-dom";
import Home from "./routes/home/home.component";
import Navigation from "./navigation/Navigation.component";
import SignIn from "./routes/sign-in/Sign-in.component";



const Shop =()=> {
    return (
        <h1>I am the shop page</h1>
    )
}



const App =()=> {

    return (
        <Routes>
            <Route path="/" element={<Navigation />}>
                 <Route index element={<Home />} />
                <Route path="/shop" element={<Shop />}/>
                <Route path="/sign-in" element={<SignIn />}/>
            </Route>
        </Routes>
        
    );
};

export default App;



/* 

1) go to firestore database then create database and start with production mode

after this you have an empty database click rules: those rules allow who can 
modify what documents inside we. 

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}

 allow read, write: if true;  this one we switch to true;
 and hit publish

 this will allow us to make any modifications we want to any document inside of the database

 we can now start implementing storing users inside of 
 our cloud store;


 go to firebase.utils.js

 */