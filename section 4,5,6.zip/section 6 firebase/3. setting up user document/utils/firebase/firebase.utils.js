import {initializeApp} from "firebase/app";
import {
    getAuth,
    signInWithRedirect, 
    signInWithPopup,
    GoogleAuthProvider,
} from "firebase/auth";

import {getFirestore, 
doc, 
getDoc, setDoc,
} from "firebase/firestore"


// Your web app's Firebase configuration 
const firebaseConfig = {
  apiKey: "AIzaSyD_71xyOI7M4Qc1ztoeTkE7Ikeldp7QEE8",
  authDomain: "e-commerceclothing.firebaseapp.com",
  projectId: "e-commerceclothing",
  storageBucket: "e-commerceclothing.appspot.com",
  messagingSenderId: "224480968643",
  appId: "1:224480968643:web:a6502c0d1766e3e1bcc776"
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);


const provider = new GoogleAuthProvider();
provider.setCustomParameters({
    prompt: "select_account"
});


export const auth = getAuth();
export const signInWithGooglePopup =()=> signInWithPopup(auth, provider);

export const db = getFirestore();

export const createUserDocumentFromAuth = async (userAuth) => {
  const userDocRef = doc(db, "users", userAuth.uid);

  console.log(userDocRef);


  const userSnapshot = await getDoc(userDocRef)
  console.log(userSnapshot);
  console.log(userSnapshot.exists());
};

/*

just like firebase/app and  firebase/auth" firestore is a different service so 
you need to import some methods from firebase/firestore

1) getFirestore is to instanciate our firestore
doc - allows us to retrieve documents inside of 
our fire store database, but how do you get that data??
how do you set the data on those documents?! 

this is where you need getDoc, setDoc methods;
doc takes 3 arguments - first is database( this is getFirestore) 
second is collection in our case it is "users"
third is identifier (for this to work we need a unique id)

2) export const db = getFirestore() -- we use it in order 
to aceess our database, so this allows us 
to tell document or we want to set the document,
 this directly points to the database inside of our console, 
but in order to use it we create some method: 

export const createUserDocumentFromAuth = async (userAuth) => {
  const userDocRef = doc(db, "users", userAuth.uid);

  console.log(userDocRef);
};

now  if we set the data inside of users for the specific id we use getDoc method: 


export const createUserDocumentFromAuth = async (userAuth) => {
  const userDocRef = doc(db, "users", userAuth.uid);

  console.log(userDocRef);


  const userSnapshot = await getDoc(userDocRef)
  console.log(userSnapshot);
  console.log(userSnapshot.exists());
};


console.log(userSnapshot.exists()); this is how you can check if there is data in firebase
*/


