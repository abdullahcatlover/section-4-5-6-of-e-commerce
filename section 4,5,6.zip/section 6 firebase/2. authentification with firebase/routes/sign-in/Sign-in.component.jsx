import {signInWithGooglePopup} from "../../utils/firebase/firebase.utils";

const SignIn =()=> {

    const logGoogleUser = async () => {
        const response = await signInWithGooglePopup();
        console.log(response);
    }
    return (
        <div>
            <h1>Sign In Page</h1>
            <button onClick={logGoogleUser}>Sign In with google PopUp</button>
        </div>
    )
}

export default SignIn;


/*
   <button onClick={logGoogleUser}>Sign In with google PopUp</button>

   after this we get back our UserCredentialImp;


   1) accessToken: "eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ3YjE5MTI0MGZjZmY 
   we get here access token using which we make crud request

*/