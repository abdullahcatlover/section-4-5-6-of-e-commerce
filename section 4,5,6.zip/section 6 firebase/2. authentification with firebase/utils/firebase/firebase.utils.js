/*1*/import {initializeApp} from "firebase/app";
import {
    getAuth,
    signInWithRedirect, 
    signInWithPopup, 
    GoogleAuthProvider,
} from "firebase/auth"


// Your web app's Firebase configuration 
/*1*/const firebaseConfig = {
  apiKey: "AIzaSyD_71xyOI7M4Qc1ztoeTkE7Ikeldp7QEE8",
  authDomain: "e-commerceclothing.firebaseapp.com",
  projectId: "e-commerceclothing",
  storageBucket: "e-commerceclothing.appspot.com",
  messagingSenderId: "224480968643",
  appId: "1:224480968643:web:a6502c0d1766e3e1bcc776"
};

// Initialize Firebase
/*1*/const firebaseApp = initializeApp(firebaseConfig);


/*2*/const provider = new GoogleAuthProvider();
provider.setCustomParameters({
    prompt: "select_account"
});


export const auth = getAuth();
export const signInWithGooglePopup =()=> signInWithPopup(auth, provider)


/*
1)initializeApp - Creates and initializes a @firebase/app#FirebaseApp instance.

*this instance that we are using should be referring to the one that
 you have created inside of firebase console

 2) "const firebaseConfig": this config identifies this one  "const app = initializeApp(firebaseConfig);"

 so these are crud actions, creating, reading, updating, destroying, 
 all of these things happen using this: "const app = initializeApp(firebaseConfig);"


 YOU SWITCHED app TO firebaseApp!!!!!!!!!

 3) you need your own config, this allows you to make firebase actions(CRUD);

 4) GoogleAuthProvider this is to use google authentification

 5) const provider = new GoogleAuthProvider();
provider.setCustomParameters({
    prompt: "select_account"


    everytime somebody interracts with our provider we force them to sellect 
    an account

    setCustomParameters - Sets the Auth custom parameters to pass
    in an Auth request for popup and redirect sign-in operations.
});

6) export const auth = getAuth() this is to make instance

7) go to firebase, and google console, click Authentication then sign-in-method 
then click choose google and enable this;
now you should have an access,

go to sign-in.component.jsx.

*/