import { Routes, Route } from "react-router-dom";
import Home from "./routes/home/home.component";




const Shop =()=> {
    return (
        <h1>I am the shop page</h1>
    )
}


const App =()=> {

    return (
        <Routes>
            <Route path="/home" element={<Home />}>
                <Route path="/shop" element={<Shop />}/>
            </Route>
        </Routes>
        
    );
};

export default App;



/*
1)
<Routes>
            <Route path="/" element={<Home />}>
                <Route path="/shop" element={<Shop />}/>
            </Route>
        </Routes> 

        now it won't work, cause we did not tell to the shop component where to go.
        we need to go to parent level component and tell to the DOM to render the matching nested 
        element. you use <Outlet><Outlet/>

        Outlet - Renders the child route's element, if there is one.
*/