import { Routes, Route, Outlet } from "react-router-dom";
import Home from "./routes/home/home.component";




const Navigation =()=> {
    return (
        <div>
            <div>
                <h1>I am the navigation bar</h1>
            </div>
            <Outlet />
        </div>
    )
}


const Shop =()=> {
    return (
        <h1>I am the shop page</h1>
    )
}


const App =()=> {

    return (
        <Routes>
            <Route path="/" element={<Navigation />}>
                 <Route index element={<Home />} />
                <Route path="/shop" element={<Shop />}/>
            </Route>
        </Routes>
        
    );
};

export default App;



/*
1)
here is the problem, directory route stays percistant despite 
the subroute, for this reason, we need to make top level navigation component


2) we replaced path with index, this is so that navigation would always be visible, 
"index "
THIS IS CALLED TOP LEVEL COMPONENT
*/