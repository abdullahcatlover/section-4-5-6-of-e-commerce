import { Fragment } from "react";
import { Outlet, Link } from "react-router-dom"

const Navigation =()=> {
    return (
        <Fragment>
            <div className="navigation">
                <Link className="logo-container" to="/">
                   <div>logo</div>
                </Link>
                <div className="links-container">
                   <Link className="nav-link" to="/shop">
                        Shop
                   </Link>
                </div>
            </div>
            <Outlet />
        </Fragment>
    )
}

export default Navigation;

/* Fragment is like top level component ofcourse if you do not 
want to use some html element, one it renders nothing renders on the page */