import { Routes, Route } from "react-router-dom";
import Home from "./routes/home/home.component";





const App =()=> {

    return (
        <Routes>
            <Route path="/" element={<Home />}/>
        </Routes>
        
    );
};

export default App;

/*npm install react-router-dom@6   you should must it*/

/* Routes - A container for a nested tree
 of elements that renders the branch that best matches the current location 
 
 Route -- Declares an element that should be rendered at a certain URL path
 */